# Test Project

This is a sample project for testing Snapship deployment.

## Files
- `index.html` - Main HTML file
- `style.css` - Styling
- `script.js` - JavaScript functionality

## Features
- Responsive design
- Interactive button
- Modern gradient background
